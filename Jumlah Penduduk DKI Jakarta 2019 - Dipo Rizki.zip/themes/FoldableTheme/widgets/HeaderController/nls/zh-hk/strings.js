define({
  "_widgetLabel": "頁首控制器",
  "signin": "登入",
  "signout": "登出",
  "about": "關於",
  "signInTo": "登入到",
  "cantSignOutTip": "此功能不適用於預覽模式。",
  "more": "更多"
});